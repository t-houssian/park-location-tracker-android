# park-location-tracker-android
This is an android app that tracks your location of where you have been and draws a line along the GPS coordinates so that you can find your way around the wilderness even without WiFi.

This app is written in Kotlin

## Project Maintainers:
- Riley Dixon
- Tyler Houssian
- Adam Rathjen
- Cameron Hansen
- Joseph Payne
